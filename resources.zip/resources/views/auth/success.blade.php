<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body dir="rtl">
<center>
    <H1>عملیات با موفقیت انجام شد.</H1>
    <h3>به برنامه برگردید و فرایند ورود به حساب کاربری را انجام دهید</h3>
    <p>با تشکر، تیم پشتیبانی باجتینو</p>
</center>
</body>
</html>
